package com.example.dlist;

import org.junit.jupiter.api.Test;

import java.util.EmptyStackException;

import static org.junit.jupiter.api.Assertions.*;

class LinkedStackTest {

    @Test
    void pushPopPeekLifoOrder() {
        LinkedStack<Integer> stack = new LinkedStack<>();
        assertTrue(stack.isEmpty());
        
        stack.push(1);
        stack.push(2);
        stack.push(3);
        assertEquals(3, stack.size());
        assertEquals("[1, 2, 3]", stack.toString());

        assertEquals(3, stack.peek());
        assertEquals(3, stack.pop());
        assertEquals(2, stack.pop());
        assertEquals(1, stack.pop());
        assertTrue(stack.isEmpty());
    }

    @Test
    void peekAndPopOnEmptyThrow() {
        LinkedStack<String> stack = new LinkedStack<>();
        assertThrows(EmptyStackException.class, stack::peek);
        assertThrows(EmptyStackException.class, stack::pop);
    }

    @Test
    void clearEmptiesStack() {
        LinkedStack<String> stack = new LinkedStack<>();
        stack.push("a");
        stack.push("b");
        assertFalse(stack.isEmpty());
        stack.clear();
        assertTrue(stack.isEmpty());
        assertEquals("[]", stack.toString());
    }

    @Test
    void nullsNotAllowed() {
        LinkedStack<String> stack = new LinkedStack<>();
        assertThrows(NullPointerException.class, () -> stack.push(null));
    }
}


package com.example.dlist;

import org.junit.jupiter.api.Test;

import java.util.NoSuchElementException;

import static org.junit.jupiter.api.Assertions.*;

class LinkedQueueTest {

    @Test
    void offerPollPeekFifoOrder() {
        LinkedQueue<String> queue = new LinkedQueue<>();
        assertTrue(queue.isEmpty());

        queue.offer("a");
        queue.offer("b");
        queue.offer("c");
        assertEquals(3, queue.size());
        assertEquals("[a, b, c]", queue.toString());

        assertEquals("a", queue.peek()); // non-destructive
        assertEquals("a", queue.poll()); // remove head
        assertEquals("b", queue.poll());
        assertEquals("c", queue.poll());
        assertTrue(queue.isEmpty());
        assertNull(queue.poll()); // empty -> null
        assertNull(queue.peek()); // empty -> null
    }

    @Test
    void enqueueDequeueAliasesWork() {
        LinkedQueue<Integer> queue = new LinkedQueue<>();
        queue.enqueue(10);
        queue.enqueue(20);
        queue.enqueue(30);
        assertEquals(3, queue.size());
        assertEquals(10, queue.dequeue());
        assertEquals(20, queue.dequeue());
        assertEquals(30, queue.dequeue());
        assertTrue(queue.isEmpty());
        assertThrows(NoSuchElementException.class, queue::dequeue);
    }

    @Test
    void nullsNotAllowed() {
        LinkedQueue<String> queue = new LinkedQueue<>();
        assertThrows(NullPointerException.class, () -> queue.offer(null));
        assertThrows(NullPointerException.class, () -> queue.enqueue(null));
    }

    @Test
    void clearEmptiesQueue() {
        LinkedQueue<String> queue = new LinkedQueue<>();
        queue.offer("x");
        queue.offer("y");
        assertFalse(queue.isEmpty());
        queue.clear();
        assertTrue(queue.isEmpty());
        assertNull(queue.peek());
        assertNull(queue.poll());
        assertEquals("[]", queue.toString());
    }
}


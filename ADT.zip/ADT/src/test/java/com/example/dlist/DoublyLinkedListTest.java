package com.example.dlist;

import org.junit.jupiter.api.Test;

import java.util.*;

import static org.junit.jupiter.api.Assertions.*;

class DoublyLinkedListTest {

    @Test
    void emptyListBasics() {
        DoublyLinkedList<Integer> list = new DoublyLinkedList<>();
        assertTrue(list.isEmpty());
        assertEquals(0, list.size());
        assertEquals(-1, list.indexOf(5));
        assertEquals(-1, list.lastIndexOf(5));
        assertFalse(list.contains(1));
        assertThrows(NoSuchElementException.class, list::getFirst);
        assertThrows(NoSuchElementException.class, list::getLast);
        assertThrows(NoSuchElementException.class, list::removeFirst);
        assertThrows(NoSuchElementException.class, list::removeLast);
    }

    @Test
    void addFirstAndLastOrder() {
        DoublyLinkedList<String> list = new DoublyLinkedList<>();
        list.addFirst("b");
        list.addFirst("a");
        list.addLast("c");
        assertEquals(3, list.size());
        assertEquals("a", list.getFirst());
        assertEquals("c", list.getLast());
        assertEquals("[a, b, c]", list.toString());
    }

    @Test
    void addAtVariousPositions() {
        DoublyLinkedList<Integer> list = new DoublyLinkedList<>();
        list.add(0, 2); // [2]
        list.add(0, 1); // [1,2]
        list.add(2, 4); // [1,2,4]
        list.add(2, 3); // [1,2,3,4]
        assertEquals("[1, 2, 3, 4]", list.toString());
        assertEquals(4, list.size());
        assertEquals(1, list.get(0));
        assertEquals(3, list.get(2));
        assertEquals(4, list.get(3));
    }

    @Test
    void removeOperations() {
        DoublyLinkedList<String> list = new DoublyLinkedList<>();
        list.add("a");
        list.add("b");
        list.add("c");
        assertEquals("a", list.removeFirst()); // [b, c]
        assertEquals("c", list.removeLast());  // [b]
        assertTrue(list.remove("b"));
        assertFalse(list.remove("z"));
        assertTrue(list.isEmpty());
        list.add("x");
        list.add("y");
        list.add("z");
        assertEquals("y", list.removeAt(1));
        assertEquals("[x, z]", list.toString());
    }

    @Test
    void indexOfAndLastIndexOfWithDuplicates() {
        DoublyLinkedList<Integer> list = new DoublyLinkedList<>();
        list.add(1);
        list.add(2);
        list.add(1);
        list.add(3);
        list.add(1);
        assertEquals(0, list.indexOf(1));
        assertEquals(4, list.lastIndexOf(1));
        assertEquals(-1, list.indexOf(99));
    }

    @Test
    void iteratorForwardBackwardAndRemove() {
        DoublyLinkedList<Integer> list = new DoublyLinkedList<>();
        list.add(1);
        list.add(2);
        list.add(3);

        ListIterator<Integer> it = list.listIterator();
        assertTrue(it.hasNext());
        assertEquals(1, it.next());
        assertEquals(2, it.next());
        assertTrue(it.hasPrevious());
        assertEquals(2, it.previous());

        // Remove last returned (which is 2)
        it.remove();
        assertEquals("[1, 3]", list.toString());

        // Add and set via iterator
        it.add(4); // inserts before 'next' (which currently returns 3)
        assertEquals("[1, 4, 3]", list.toString());

        assertEquals(3, it.next());
        it.set(5);
        assertEquals("[1, 4, 5]", list.toString());
    }

    @Test
    void failFastIteratorOnStructuralChange() {
        DoublyLinkedList<String> list = new DoublyLinkedList<>();
        list.add("a");
        list.add("b");
        var it = list.iterator();
        list.add("c"); // structural modification after iterator creation
        assertThrows(ConcurrentModificationException.class, it::next);
    }

    @Test
    void clearAndClone() {
        DoublyLinkedList<String> list = new DoublyLinkedList<>();
        list.add("a");
        list.add("b");
        list.add("c");
        DoublyLinkedList<String> copy = list.clone();
        assertNotSame(list, copy);
        assertEquals(list.toString(), copy.toString());

        list.clear();
        assertTrue(list.isEmpty());
        assertEquals("[a, b, c]", copy.toString());
    }

    @Test
    void boundsChecks() {
        DoublyLinkedList<Integer> list = new DoublyLinkedList<>();
        list.add(0, 1);
        assertThrows(IndexOutOfBoundsException.class, () -> list.add(3, 5));
        assertThrows(IndexOutOfBoundsException.class, () -> list.get(-1));
        assertThrows(IndexOutOfBoundsException.class, () -> list.get(2));
        assertThrows(IndexOutOfBoundsException.class, () -> list.removeAt(2));
        assertThrows(IndexOutOfBoundsException.class, () -> list.listIterator(5));
    }

    @Test
    void singleElementListOperations() {
        DoublyLinkedList<String> list = new DoublyLinkedList<>();
        list.add("only");
        assertEquals(1, list.size());
        assertFalse(list.isEmpty());
        assertEquals("only", list.getFirst());
        assertEquals("only", list.getLast());
        assertEquals("only", list.get(0));
        assertEquals(0, list.indexOf("only"));
        assertEquals(0, list.lastIndexOf("only"));
        assertTrue(list.contains("only"));
        
        assertEquals("only", list.removeFirst());
        assertTrue(list.isEmpty());
        
        list.add("new");
        assertEquals("new", list.removeLast());
        assertTrue(list.isEmpty());
        
        list.add("another");
        assertEquals("another", list.removeAt(0));
        assertTrue(list.isEmpty());
    }

    @Test
    void iteratorOnEmptyList() {
        DoublyLinkedList<Integer> list = new DoublyLinkedList<>();
        var it = list.iterator();
        assertFalse(it.hasNext());
        assertThrows(NoSuchElementException.class, it::next);
        
        ListIterator<Integer> lit = list.listIterator();
        assertFalse(lit.hasNext());
        assertFalse(lit.hasPrevious());
        assertEquals(0, lit.nextIndex());
        assertEquals(-1, lit.previousIndex());
        assertThrows(NoSuchElementException.class, lit::next);
        assertThrows(NoSuchElementException.class, lit::previous);
    }

    @Test
    void multipleConsecutiveIteratorRemoves() {
        DoublyLinkedList<Integer> list = new DoublyLinkedList<>();
        list.add(1);
        list.add(2);
        list.add(3);
        
        ListIterator<Integer> it = list.listIterator();
        it.next(); // 1
        it.remove();
        assertEquals("[2, 3]", list.toString());
        
        it.next(); // 2
        it.remove();
        assertEquals("[3]", list.toString());
        
        it.next(); // 3
        it.remove();
        assertTrue(list.isEmpty());
        
        // Try to remove again without calling next/previous
        assertThrows(IllegalStateException.class, it::remove);
    }

    @Test
    void nullElementHandling() {
        DoublyLinkedList<String> list = new DoublyLinkedList<>();
        list.add(null);
        list.add("a");
        list.add(null);
        
        assertEquals(3, list.size());
        assertTrue(list.contains(null));
        assertEquals(0, list.indexOf(null));
        assertEquals(2, list.lastIndexOf(null));
        
        assertTrue(list.remove(null));
        assertEquals("[a, null]", list.toString());
        
        assertEquals(null, list.get(1));
        list.set(1, "b");
        assertEquals("b", list.get(1));
    }

    @Test
    void equalsAndHashCode() {
        DoublyLinkedList<Integer> list1 = new DoublyLinkedList<>();
        list1.add(1);
        list1.add(2);
        list1.add(3);
        
        DoublyLinkedList<Integer> list2 = new DoublyLinkedList<>();
        list2.add(1);
        list2.add(2);
        list2.add(3);
        
        DoublyLinkedList<Integer> list3 = new DoublyLinkedList<>();
        list3.add(1);
        list3.add(2);
        list3.add(4);
        
        // Equals tests
        assertEquals(list1, list2);
        assertNotEquals(list1, list3);
        assertNotEquals(list1, null);
        assertEquals(list1, list1); // reflexive
        
        // HashCode tests
        assertEquals(list1.hashCode(), list2.hashCode());
        // Note: different lists can have same hash, but equal lists must have same hash
        assertTrue(list1.equals(list2) == (list1.hashCode() == list2.hashCode()));
        
        // Empty lists
        DoublyLinkedList<Integer> empty1 = new DoublyLinkedList<>();
        DoublyLinkedList<Integer> empty2 = new DoublyLinkedList<>();
        assertEquals(empty1, empty2);
        assertEquals(empty1.hashCode(), empty2.hashCode());
        
        // Different types
        DoublyLinkedList<String> stringList = new DoublyLinkedList<>();
        stringList.add("1");
        stringList.add("2");
        stringList.add("3");
        assertNotEquals(list1, stringList);

        // Cross-type equality with standard List is intentionally not supported
        // to preserve symmetry with JDK List's equals contract.
    }

    @Test
    void iteratorRemoveAfterNextAndPrevious() {
        DoublyLinkedList<Integer> list = new DoublyLinkedList<>();
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(4);
        
        ListIterator<Integer> it = list.listIterator();
        it.next(); // 1
        it.next(); // 2
        it.remove(); // remove 2 after next()
        assertEquals("[1, 3, 4]", list.toString());
        assertEquals(1, it.nextIndex());
        
        it.previous(); // 1
        it.remove(); // remove 1 after previous()
        assertEquals("[3, 4]", list.toString());
        assertEquals(0, it.nextIndex());
    }

    @Test
    void iteratorSetWithoutNextOrPrevious() {
        DoublyLinkedList<Integer> list = new DoublyLinkedList<>();
        list.add(1);
        list.add(2);
        
        ListIterator<Integer> it = list.listIterator();
        assertThrows(IllegalStateException.class, () -> it.set(99));
        
        it.next(); // 1
        it.set(10);
        assertEquals("[10, 2]", list.toString());
        
        it.next(); // 2
        it.previous(); // back to 2
        it.set(20);
        assertEquals("[10, 20]", list.toString());
    }

    @Test
    void iteratorAddMultipleTimes() {
        DoublyLinkedList<Integer> list = new DoublyLinkedList<>();
        ListIterator<Integer> it = list.listIterator();
        
        it.add(1);
        it.add(2);
        it.add(3);
        assertEquals("[1, 2, 3]", list.toString());
        
        // Add in middle
        it = list.listIterator(1);
        it.add(99);
        assertEquals("[1, 99, 2, 3]", list.toString());
    }

    @Test
    void removeByIndex() {
        DoublyLinkedList<String> list = new DoublyLinkedList<>();
        list.add("a");
        list.add("b");
        list.add("c");
        
        // Test remove(int index) - Java List compatibility
        assertEquals("b", list.remove(1));
        assertEquals("[a, c]", list.toString());
        
        assertEquals("a", list.remove(0));
        assertEquals("[c]", list.toString());
        
        assertEquals("c", list.remove(0));
        assertTrue(list.isEmpty());
    }

    @Test
    void constructorFromCollection() {
        List<Integer> source = Arrays.asList(1, 2, 3, 4, 5);
        DoublyLinkedList<Integer> list = new DoublyLinkedList<>(source);
        
        assertEquals(5, list.size());
        assertEquals("[1, 2, 3, 4, 5]", list.toString());
        assertEquals(1, list.get(0));
        assertEquals(5, list.get(4));
        
        // Test with empty collection
        List<String> empty = new ArrayList<>();
        DoublyLinkedList<String> emptyList = new DoublyLinkedList<>(empty);
        assertTrue(emptyList.isEmpty());
        
        // Test null collection
        assertThrows(NullPointerException.class, () -> new DoublyLinkedList<>(null));
    }

    @Test
    void toArrayMethods() {
        DoublyLinkedList<String> list = new DoublyLinkedList<>();
        list.add("a");
        list.add("b");
        list.add("c");
        
        // Test toArray()
        Object[] objArray = list.toArray();
        assertEquals(3, objArray.length);
        assertEquals("a", objArray[0]);
        assertEquals("b", objArray[1]);
        assertEquals("c", objArray[2]);
        
        // Test toArray(T[] a) with array too small
        String[] strArray = list.toArray(new String[0]);
        assertEquals(3, strArray.length);
        assertEquals("a", strArray[0]);
        assertEquals("b", strArray[1]);
        assertEquals("c", strArray[2]);
        
        // Test toArray(T[] a) with array exactly right size
        String[] exactArray = list.toArray(new String[3]);
        assertEquals(3, exactArray.length);
        assertEquals("a", exactArray[0]);
        assertEquals("b", exactArray[1]);
        assertEquals("c", exactArray[2]);
        
        // Test toArray(T[] a) with array larger than needed
        String[] largeArray = list.toArray(new String[5]);
        assertEquals(5, largeArray.length);
        assertEquals("a", largeArray[0]);
        assertEquals("b", largeArray[1]);
        assertEquals("c", largeArray[2]);
        assertNull(largeArray[3]); // Should be null after size
        assertNull(largeArray[4]);
        
        // Test null array
        assertThrows(NullPointerException.class, () -> list.toArray((String[]) null));
        
        // Test empty list
        DoublyLinkedList<Integer> empty = new DoublyLinkedList<>();
        Object[] emptyArray = empty.toArray();
        assertEquals(0, emptyArray.length);
        
        Integer[] emptyIntArray = empty.toArray(new Integer[0]);
        assertEquals(0, emptyIntArray.length);
    }

    @Test
    void removeOverloadResolution() {
        DoublyLinkedList<Integer> list = new DoublyLinkedList<>();
        list.add(1);
        list.add(2);
        list.add(3);
        list.add(2);
        
        // remove(int index) should remove by index
        assertEquals(2, list.remove(1)); // removes element at index 1
        assertEquals("[1, 3, 2]", list.toString());
        
        // remove(Object o) should remove by value
        assertTrue(list.remove(Integer.valueOf(2))); // removes first occurrence of 2
        assertEquals("[1, 3]", list.toString());
        
        // remove(int index) with Integer object should still work
        list.add(0, 5);
        assertEquals(5, list.remove(0)); // removes at index 0
        assertEquals("[1, 3]", list.toString());
    }
}

package com.example.tree;

import org.junit.jupiter.api.Test;

import java.util.Arrays;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

class BinarySearchTreeTest {

    private BinarySearchTree<Integer> buildExampleTree() {
        // Inserts: 8, 3, 10, 1, 6, 14, 4, 7, 13
        BinarySearchTree<Integer> bst = new BinarySearchTree<>();
        List<Integer> vals = Arrays.asList(8, 3, 10, 1, 6, 14, 4, 7, 13);
        for (int v : vals) assertTrue(bst.add(v));
        return bst;
    }

    @Test
    void insertContainsSize() {
        BinarySearchTree<Integer> bst = new BinarySearchTree<>();
        assertTrue(bst.isEmpty());
        assertTrue(bst.add(5));
        assertTrue(bst.add(2));
        assertTrue(bst.add(8));
        assertFalse(bst.add(5)); // duplicate
        assertEquals(3, bst.size());
        assertTrue(bst.contains(2));
        assertFalse(bst.contains(99));
    }

    @Test
    void traversalsMatchExpectedOrders() {
        BinarySearchTree<Integer> bst = buildExampleTree();

        assertEquals(
                Arrays.asList(1, 3, 4, 6, 7, 8, 10, 13, 14),
                bst.inorder()
        );
        assertEquals(
                Arrays.asList(8, 3, 1, 6, 4, 7, 10, 14, 13),
                bst.preorder()
        );
        assertEquals(
                Arrays.asList(1, 4, 7, 6, 3, 13, 14, 10, 8),
                bst.postorder()
        );
        assertEquals(
                Arrays.asList(8, 3, 10, 1, 6, 14, 4, 7, 13),
                bst.levelOrder()
        );
    }

    @Test
    void iteratorIsInorder() {
        BinarySearchTree<Integer> bst = buildExampleTree();
        Iterator<Integer> it = bst.iterator();
        List<Integer> expected = Arrays.asList(1, 3, 4, 6, 7, 8, 10, 13, 14);
        for (Integer e : expected) assertEquals(e, it.next());
        assertFalse(it.hasNext());
    }

    @Test
    void comparatorSupport() {
        // Reverse order comparator
        BinarySearchTree<String> bst = new BinarySearchTree<>(Comparator.reverseOrder());
        bst.add("b");
        bst.add("a");
        bst.add("c");
        // In-order should reflect reverse ordering
        assertEquals(Arrays.asList("c", "b", "a"), bst.inorder());
    }

    @Test
    void clearEmptiesTree() {
        BinarySearchTree<Integer> bst = buildExampleTree();
        assertTrue(bst.size() > 0);
        bst.clear();
        assertTrue(bst.isEmpty());
        assertEquals(List.of(), bst.inorder());
        assertEquals(List.of(), bst.levelOrder());
        assertEquals(0, bst.size());
        assertEquals("[]", bst.toString());
    }

    @Test
    void removeLeafOneChildTwoChildrenAndRoot() {
        BinarySearchTree<Integer> bst = buildExampleTree();
        assertEquals(9, bst.size());

        // Remove a leaf (4)
        assertTrue(bst.remove(4));
        assertEquals(8, bst.size());
        assertEquals(List.of(1, 3, 6, 7, 8, 10, 13, 14), bst.inorder());

        // Remove a node with one child (14 has left child 13 only)
        assertTrue(bst.remove(14));
        assertEquals(7, bst.size());
        assertEquals(List.of(1, 3, 6, 7, 8, 10, 13), bst.inorder());

        // Remove a node with two children (3)
        assertTrue(bst.remove(3));
        assertEquals(6, bst.size());
        assertEquals(List.of(1, 6, 7, 8, 10, 13), bst.inorder());

        // Remove the root (8), which currently has two children
        assertTrue(bst.remove(8));
        assertEquals(5, bst.size());
        assertEquals(List.of(1, 6, 7, 10, 13), bst.inorder());

        // Remove root-only tree
        BinarySearchTree<Integer> single = new BinarySearchTree<>();
        assertTrue(single.add(42));
        assertTrue(single.remove(42));
        assertTrue(single.isEmpty());
        assertEquals(-1, single.height());
    }

    @Test
    void removeNonExistentAndEmpty() {
        BinarySearchTree<Integer> bst = buildExampleTree();
        int before = bst.size();
        assertFalse(bst.remove(999));
        assertEquals(before, bst.size());

        BinarySearchTree<Integer> empty = new BinarySearchTree<>();
        assertFalse(empty.remove(1));
    }

    @Test
    void minMaxAndExceptions() {
        BinarySearchTree<Integer> bst = buildExampleTree();
        assertEquals(1, bst.min());
        assertEquals(14, bst.max());

        BinarySearchTree<Integer> empty = new BinarySearchTree<>();
        assertThrows(java.util.NoSuchElementException.class, empty::min);
        assertThrows(java.util.NoSuchElementException.class, empty::max);
    }

    @Test
    void heightValues() {
        BinarySearchTree<Integer> empty = new BinarySearchTree<>();
        assertEquals(-1, empty.height());
        empty.add(5);
        assertEquals(0, empty.height());

        BinarySearchTree<Integer> bst = buildExampleTree();
        // For the constructed example, height should be 3
        assertEquals(3, bst.height());
    }

    @Test
    void iteratorExhaustionThrows() {
        BinarySearchTree<Integer> bst = buildExampleTree();
        Iterator<Integer> it = bst.iterator();
        while (it.hasNext()) it.next();
        assertThrows(java.util.NoSuchElementException.class, it::next);
    }
}

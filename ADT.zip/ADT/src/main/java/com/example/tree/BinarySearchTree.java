package com.example.tree;

import com.example.dlist.LinkedQueue;

import java.util.ArrayDeque;
import java.util.ArrayList;
import java.util.Comparator;
import java.util.Iterator;
import java.util.List;
import java.util.NoSuchElementException;
import java.util.Objects;

/**
 * A generic Binary Search Tree (BST) with optional comparator support.
 *
 * <p>Best practices followed:
 * - Encapsulated node type and invariants (left {@literal <} node {@literal <} right using comparator or natural order)
 * - Disallows null elements to keep ordering well-defined
 * - Clear, documented traversal methods (pre-order, in-order, post-order) and breadth-first (level-order)
 * - Provides {@link Iterable} over in-order traversal by default</p>
 *
 * <p>Complexity (average-case):
 * - insert/contains: O(log n) on balanced trees, O(n) worst-case
 * - traversals: O(n)</p>
 *
 * @param <E> element type
 */
public final class BinarySearchTree<E> implements Iterable<E> {

    /**
     * Binary tree node containing an element and references to left and right children.
     *
     * @param <E> the type of element stored in this node
     */
    private static final class Node<E> {
        E item;
        Node<E> left;
        Node<E> right;

        /**
         * Constructs a new node with the specified item and no children.
         *
         * @param item the element to store in this node
         */
        Node(E item) { this.item = item; }
    }

    private Node<E> root;
    private int size;
    private final Comparator<? super E> comparator;

    /**
     * Constructs an empty BST using natural ordering.
     * Elements must implement {@link Comparable} and be mutually comparable.
     */
    public BinarySearchTree() {
        this(null);
    }

    /**
     * Constructs an empty BST using the provided comparator. If {@code comparator}
     * is {@code null}, natural ordering is used.
     *
     * @param comparator comparator to determine element order, or null for natural ordering
     */
    public BinarySearchTree(Comparator<? super E> comparator) {
        this.comparator = comparator;
    }

    /**
     * Returns the number of elements in this tree.
     *
     * @return the number of elements in this tree
     */
    public int size() { return size; }

    /**
     * Returns {@code true} if this tree contains no elements.
     *
     * @return {@code true} if this tree contains no elements
     */
    public boolean isEmpty() { return size == 0; }

    /**
     * Removes all elements from this tree. The tree will be empty
     * after this call returns.
     */
    public void clear() {
        root = null;
        size = 0;
    }

    /**
     * Inserts the specified element if not already present.
     *
     * @param e element to insert (must be non-null)
     * @return {@code true} if the element was inserted, {@code false} if it was a duplicate
     * @throws NullPointerException if {@code e} is null
     */
    public boolean add(E e) {
        Objects.requireNonNull(e, "BST does not permit null elements");
        if (root == null) {
            root = new Node<>(e);
            size = 1;
            return true;
        }

        Node<E> curr = root;
        while (true) {
            int cmp = compare(e, curr.item);
            if (cmp == 0) return false; // duplicate
            else if (cmp < 0) {
                if (curr.left == null) {
                    curr.left = new Node<>(e);
                    size++;
                    return true;
                }
                curr = curr.left;
            } else { // cmp > 0
                if (curr.right == null) {
                    curr.right = new Node<>(e);
                    size++;
                    return true;
                }
                curr = curr.right;
            }
        }
    }

    /**
     * Returns {@code true} if this tree contains the specified element.
     *
     * @param e element whose presence is to be tested (must be non-null)
     * @return {@code true} if this tree contains the specified element
     * @throws NullPointerException if {@code e} is null
     */
    public boolean contains(E e) {
        Objects.requireNonNull(e, "element");
        Node<E> curr = root;
        while (curr != null) {
            int cmp = compare(e, curr.item);
            if (cmp == 0) return true;
            curr = (cmp < 0) ? curr.left : curr.right;
        }
        return false;
    }

    /**
     * Removes the specified element from this tree if it is present.
     *
     * @param e element to be removed from this tree (must be non-null)
     * @return {@code true} if this tree contained the specified element
     * @throws NullPointerException if {@code e} is null
     */
    public boolean remove(E e) {
        Objects.requireNonNull(e, "element");
        if (root == null) return false;
        int oldSize = size;
        root = remove(root, e);
        return size < oldSize;
    }

    /**
     * Returns the minimum element in this tree according to the comparator.
     *
     * @return the minimum element in this tree
     * @throws NoSuchElementException if this tree is empty
     */
    public E min() {
        if (root == null) throw new NoSuchElementException("Tree is empty");
        Node<E> curr = root;
        while (curr.left != null) curr = curr.left;
        return curr.item;
    }

    /**
     * Returns the maximum element in this tree according to the comparator.
     *
     * @return the maximum element in this tree
     * @throws NoSuchElementException if this tree is empty
     */
    public E max() {
        if (root == null) throw new NoSuchElementException("Tree is empty");
        Node<E> curr = root;
        while (curr.right != null) curr = curr.right;
        return curr.item;
    }

    /**
     * Returns the height of this tree. The height of an empty tree is -1,
     * and the height of a tree with a single node is 0.
     *
     * @return the height of this tree
     */
    public int height() {
        return height(root);
    }

    // ---------------- Traversals ----------------

    /**
     * Returns a list of elements in in-order traversal (Left, Node, Right).
     * For BSTs, this yields sorted order according to the comparator.
     *
     * @return a list of elements in in-order traversal order (sorted order)
     */
    public List<E> inorder() {
        List<E> out = new ArrayList<>(size);
        inorder(root, out);
        return out;
    }

    /**
     * Returns a list of elements in pre-order traversal (Node, Left, Right).
     * Pre-order visits the node before its children, useful for creating a copy
     * of the tree or prefix expression evaluation.
     *
     * @return a list of elements in pre-order traversal order
     */
    public List<E> preorder() {
        List<E> out = new ArrayList<>(size);
        preorder(root, out);
        return out;
    }

    /**
     * Returns a list of elements in post-order traversal (Left, Right, Node).
     * Post-order visits the node after its children, useful for deleting the
     * tree or postfix expression evaluation.
     *
     * @return a list of elements in post-order traversal order
     */
    public List<E> postorder() {
        List<E> out = new ArrayList<>(size);
        postorder(root, out);
        return out;
    }

    /**
     * Returns a list of elements in level-order traversal, also known as Breadth-First Search (BFS).
     *
     * <p>In BFS for a binary tree, we visit nodes one level at a time, starting from the root.
     * At each step, the current node is removed from the front of a queue, its value is processed,
     * and then its left and right children (if any) are added to the back of the queue.
     * This process repeats until the queue is empty, guaranteeing that nodes are visited in order
     * from top to bottom and from left to right within each level.</p>
     *
     * <p>BFS is useful for:</p>
     * <ul>
     *   <li>Discovering properties like the minimum depth</li>
     *   <li>Finding the shortest path between the root and any node</li>
     *   <li>Printing the structure of a tree in level order</li>
     *   <li>Serializing or deserializing a tree efficiently</li>
     *   <li>Operations where processing nodes level by level is needed</li>
     * </ul>
     *
     * @return a list of elements as they appear in level-order (BFS) traversal
     */
    public List<E> levelOrder() {
        List<E> out = new ArrayList<>(size);
        if (root == null) return out;
        LinkedQueue<Node<E>> q = new LinkedQueue<>();
        q.enqueue(root);
        while (!q.isEmpty()) {
            Node<E> n = q.dequeue();
            out.add(n.item);
            if (n.left != null) q.enqueue(n.left);
            if (n.right != null) q.enqueue(n.right);
        }
        return out;
    }

    /**
     * Performs an in-order traversal starting from the specified node,
     * adding elements to the output list.
     *
     * @param n the node to start traversal from (may be null)
     * @param out the list to add elements to during traversal
     */
    private void inorder(Node<E> n, List<E> out) {
        if (n == null) return;
        inorder(n.left, out);
        out.add(n.item);
        inorder(n.right, out);
    }

    /**
     * Performs a pre-order traversal starting from the specified node,
     * adding elements to the output list.
     *
     * @param n the node to start traversal from (may be null)
     * @param out the list to add elements to during traversal
     */
    private void preorder(Node<E> n, List<E> out) {
        if (n == null) return;
        out.add(n.item);
        preorder(n.left, out);
        preorder(n.right, out);
    }

    /**
     * Performs a post-order traversal starting from the specified node,
     * adding elements to the output list.
     *
     * @param n the node to start traversal from (may be null)
     * @param out the list to add elements to during traversal
     */
    private void postorder(Node<E> n, List<E> out) {
        if (n == null) return;
        postorder(n.left, out);
        postorder(n.right, out);
        out.add(n.item);
    }

    // ---------------- Iterable (in-order) ----------------

    /**
     * Returns a lazy in-order iterator (Left, Node, Right).
     *
     * <p>Traversal yields elements in sorted order according to the comparator.
     * This iterator uses O(h) additional memory (h is tree height) and does not
     * allocate an intermediate list. Concurrent structural modifications are not
     * detected (no fail-fast behavior).</p>
     *
     * @return an iterator over the elements in in-order (sorted) sequence
     */
    @Override
    public Iterator<E> iterator() {
        return new InOrderIterator();
    }

    /** In-order iterator implementation using an explicit stack. */
    private final class InOrderIterator implements Iterator<E> {
        private final ArrayDeque<Node<E>> stack = new ArrayDeque<>();

        InOrderIterator() {
            pushLeft(root);
        }

        private void pushLeft(Node<E> n) {
            while (n != null) {
                stack.push(n);
                n = n.left;
            }
        }

        @Override
        public boolean hasNext() {
            return !stack.isEmpty();
        }

        @Override
        public E next() {
            if (!hasNext()) throw new java.util.NoSuchElementException();
            Node<E> n = stack.pop();
            if (n.right != null) pushLeft(n.right);
            return n.item;
        }
    }

    /**
     * Returns a string representation of this tree. The string representation
     * consists of a list of the tree's elements in in-order traversal (sorted order),
     * enclosed in square brackets ({@code "[]"}). Adjacent elements are separated
     * by the characters {@code ", "} (comma and space).
     *
     * @return a string representation of this tree
     */
    @Override
    public String toString() {
        return inorder().toString();
    }

    // ---------------- Helpers ----------------

    /**
     * Removes the specified element from the subtree rooted at the given node.
     * Returns the root of the modified subtree.
     *
     * @param node the root of the subtree to search
     * @param e the element to remove
     * @return the root of the modified subtree, or null if the subtree becomes empty
     */
    private Node<E> remove(Node<E> node, E e) {
        if (node == null) return null;

        int cmp = compare(e, node.item);
        if (cmp < 0) {
            node.left = remove(node.left, e);
        } else if (cmp > 0) {
            node.right = remove(node.right, e);
        } else {
            // Found the node to remove
            size--;
            if (node.left == null) return node.right;
            if (node.right == null) return node.left;

            // Node has two children: replace with in-order successor (min of right subtree)
            Node<E> successor = findMin(node.right);
            node.item = successor.item;
            node.right = removeMin(node.right);
        }
        return node;
    }

    /**
     * Finds the node with the minimum value in the subtree rooted at the given node.
     *
     * @param node the root of the subtree
     * @return the node with the minimum value
     */
    private Node<E> findMin(Node<E> node) {
        while (node.left != null) node = node.left;
        return node;
    }

    /**
     * Removes the minimum node from the subtree rooted at the given node.
     *
     * @param node the root of the subtree
     * @return the root of the modified subtree
     */
    private Node<E> removeMin(Node<E> node) {
        if (node.left == null) return node.right;
        node.left = removeMin(node.left);
        return node;
    }

    /**
     * Calculates the height of the subtree rooted at the given node.
     * The height of a null node is -1.
     *
     * @param node the root of the subtree (may be null)
     * @return the height of the subtree
     */
    private int height(Node<E> node) {
        if (node == null) return -1;
        return 1 + Math.max(height(node.left), height(node.right));
    }

    /**
     * Compares two elements using the comparator if available, otherwise using
     * natural ordering (Comparable).
     *
     * @param a the first element to compare
     * @param b the second element to compare
     * @return a negative integer, zero, or a positive integer as the first
     *         argument is less than, equal to, or greater than the second
     * @throws ClassCastException if the elements are not mutually comparable
     *         and no comparator is provided
     */
    @SuppressWarnings("unchecked")
    private int compare(E a, E b) {
        if (comparator != null) return comparator.compare(a, b);
        return ((Comparable<? super E>) a).compareTo(b);
    }
}

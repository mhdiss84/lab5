package com.example.dlist;

import java.util.EmptyStackException;
import java.util.Objects;

/**
 * A stack (LIFO - Last In, First Out) implementation backed by {@link DoublyLinkedList}.
 *
 * <p>This implementation provides constant-time operations for the basic stack
 * operations. The stack uses the doubly linked list's tail as the top of the stack,
 * allowing efficient push and pop operations.</p>
 *
 * <p>Performance characteristics:</p>
 * <ul>
 *   <li>push/pop/peek: O(1) time complexity</li>
 *   <li>size/isEmpty: O(1) time complexity</li>
 *   <li>clear: O(n) time complexity</li>
 * </ul>
 *
 * <p>Null values are not permitted to maintain clear semantics for empty stack
 * detection and to avoid ambiguity in return values.</p>
 *
 * @param <E> the type of elements held in this stack
 * @see DoublyLinkedList
 */
public final class LinkedStack<E> {
    /** The underlying doubly linked list backing this stack. */
    private final DoublyLinkedList<E> list = new DoublyLinkedList<>();

    /**
     * Constructs an empty stack.
     */
    public LinkedStack() {
    }

    /**
     * Pushes an element onto the top of this stack.
     *
     * @param e the element to push onto this stack
     * @throws NullPointerException if the specified element is null
     */
    public void push(E e) {
        Objects.requireNonNull(e, "Stack does not permit null elements");
        list.addLast(e);
    }

    /**
     * Removes and returns the element at the top of this stack.
     *
     * @return the element at the top of this stack
     * @throws EmptyStackException if this stack is empty
     */
    public E pop() {
        if (list.isEmpty()) throw new EmptyStackException();
        return list.removeLast();
    }

    /**
     * Looks at the element at the top of this stack without removing it from the stack.
     *
     * @return the element at the top of this stack
     * @throws EmptyStackException if this stack is empty
     */
    public E peek() {
        if (list.isEmpty()) throw new EmptyStackException();
        return list.getLast();
    }

    /**
     * Returns the number of elements in this stack.
     *
     * @return the number of elements in this stack
     */
    public int size() {
        return list.size();
    }

    /**
     * Returns {@code true} if this stack contains no elements.
     *
     * @return {@code true} if this stack contains no elements
     */
    public boolean isEmpty() {
        return list.isEmpty();
    }

    /**
     * Removes all of the elements from this stack. The stack will be empty
     * after this call returns.
     */
    public void clear() {
        list.clear();
    }

    /**
     * Returns a string representation of this stack. The string representation
     * consists of a list of the stack's elements in the order they would be
     * popped (from top to bottom), enclosed in square brackets ({@code "[]"}).
     * Adjacent elements are separated by the characters {@code ", "} (comma and space).
     *
     * @return a string representation of this stack
     */
    @Override
    public String toString() {
        return list.toString();
    }
}

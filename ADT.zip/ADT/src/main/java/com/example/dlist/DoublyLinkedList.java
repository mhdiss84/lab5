package com.example.dlist;

import java.util.Collection;
import java.util.ConcurrentModificationException;
import java.util.Iterator;
import java.util.ListIterator;
import java.util.NoSuchElementException;
import java.util.Objects;

/**
 * Generic, sentinel-based doubly linked list implementation.
 *
 * <p>Design highlights (best practices):
 * - Uses dedicated head/tail sentinel nodes to simplify edge cases.
 * - Encapsulates node operations (link/unlink) to preserve invariants.
 * - Provides fail-fast iterators backed by a modification count.
 * - Optimizes index-based traversal by scanning from nearest end.
 * - Thorough argument validation and clear exceptions.</p>
 *
 * @param <E> element type
 */
public final class DoublyLinkedList<E> implements Iterable<E>, Cloneable {

    /**
     * Doubly-linked node containing an element and references to previous and next nodes.
     *
     * @param <E> the type of element stored in this node
     */
    private static final class Node<E> {
        E item;
        Node<E> prev;
        Node<E> next;

        /**
         * Constructs a new node with the specified item and links.
         *
         * @param item the element to store in this node
         * @param prev reference to the previous node
         * @param next reference to the next node
         */
        Node(E item, Node<E> prev, Node<E> next) {
            this.item = item;
            this.prev = prev;
            this.next = next;
        }
    }

    private final Node<E> head; // sentinel head (does not store an element)
    private final Node<E> tail; // sentinel tail (does not store an element)

    private int size;
    private int modCount; // for fail-fast iterators

    /** Constructs an empty list with head/tail sentinels linked together. */
    public DoublyLinkedList() {
        head = new Node<>(null, null, null);
        tail = new Node<>(null, null, null);
        head.next = tail;
        tail.prev = head;
        size = 0;
        modCount = 0;
    }

    /**
     * Constructs a list containing the elements of the specified collection,
     * in the order they are returned by the collection's iterator.
     *
     * @param c the collection whose elements are to be placed into this list
     * @throws NullPointerException if the specified collection is null
     */
    public DoublyLinkedList(Collection<? extends E> c) {
        this();
        if (c == null) throw new NullPointerException("Collection cannot be null");
        for (E e : c) {
            addLast(e);
        }
    }

    // --------------- Basic queries ---------------

    /**
     * Returns the number of elements in this list.
     *
     * @return the number of elements in this list
     */
    public int size() {
        return size;
    }

    /**
     * Returns {@code true} if this list contains no elements.
     *
     * @return {@code true} if this list contains no elements
     */
    public boolean isEmpty() {
        return size == 0;
    }

    /**
     * Returns {@code true} if this list contains the specified element.
     *
     * @param o element whose presence in this list is to be tested
     * @return {@code true} if this list contains the specified element
     */
    public boolean contains(Object o) {
        return indexOf(o) != -1;
    }

    // --------------- Element access ---------------

    /**
     * Returns the first element in this list.
     *
     * @return the first element in this list
     * @throws NoSuchElementException if this list is empty
     */
    public E getFirst() {
        if (isEmpty()) throw new NoSuchElementException("List is empty");
        return head.next.item;
    }

    /**
     * Returns the last element in this list.
     *
     * @return the last element in this list
     * @throws NoSuchElementException if this list is empty
     */
    public E getLast() {
        if (isEmpty()) throw new NoSuchElementException("List is empty");
        return tail.prev.item;
    }

    /**
     * Returns the element at the specified position in this list.
     *
     * @param index index of the element to return
     * @return the element at the specified position in this list
     * @throws IndexOutOfBoundsException if the index is out of range
     *         ({@code index < 0 || index >= size()})
     */
    public E get(int index) {
        checkElementIndex(index);
        return nodeAt(index).item;
    }

    /**
     * Replaces the element at the specified position in this list with the
     * specified element.
     *
     * @param index index of the element to replace
     * @param element element to be stored at the specified position
     * @return the element previously at the specified position
     * @throws IndexOutOfBoundsException if the index is out of range
     *         ({@code index < 0 || index >= size()})
     */
    public E set(int index, E element) {
        checkElementIndex(index);
        Node<E> n = nodeAt(index);
        E old = n.item;
        n.item = element;
        return old;
    }

    // --------------- Add operations ---------------

    /**
     * Inserts the specified element at the beginning of this list.
     *
     * @param e the element to add
     */
    public void addFirst(E e) {
        linkBetween(e, head, head.next);
    }

    /**
     * Appends the specified element to the end of this list.
     *
     * @param e the element to add
     */
    public void addLast(E e) {
        linkBetween(e, tail.prev, tail);
    }

    /**
     * Inserts the specified element at the specified position in this list.
     * Shifts the element currently at that position (if any) and any subsequent
     * elements to the right (adds one to their indices).
     *
     * @param index index at which the specified element is to be inserted
     * @param element element to be inserted
     * @throws IndexOutOfBoundsException if the index is out of range
     *         ({@code index < 0 || index > size()})
     */
    public void add(int index, E element) {
        checkPositionIndex(index);
        if (index == size) {
            linkBetween(element, tail.prev, tail);
        } else {
            Node<E> target = nodeAt(index);
            linkBetween(element, target.prev, target);
        }
    }

    /**
     * Appends the specified element to the end of this list.
     *
     * @param e element to be appended to this list
     * @return {@code true} (as specified by {@link java.util.Collection#add})
     */
    public boolean add(E e) {
        addLast(e);
        return true;
    }

    // --------------- Remove operations ---------------

    /**
     * Removes and returns the first element from this list.
     *
     * @return the first element from this list
     * @throws NoSuchElementException if this list is empty
     */
    public E removeFirst() {
        if (isEmpty()) throw new NoSuchElementException("List is empty");
        return unlink(head.next);
    }

    /**
     * Removes and returns the last element from this list.
     *
     * @return the last element from this list
     * @throws NoSuchElementException if this list is empty
     */
    public E removeLast() {
        if (isEmpty()) throw new NoSuchElementException("List is empty");
        return unlink(tail.prev);
    }

    /**
     * Removes the element at the specified position in this list. Shifts any
     * subsequent elements to the left (subtracts one from their indices).
     * Returns the element that was removed from the list.
     *
     * @param index the index of the element to be removed
     * @return the element previously at the specified position
     * @throws IndexOutOfBoundsException if the index is out of range
     *         ({@code index < 0 || index >= size()})
     */
    public E removeAt(int index) {
        checkElementIndex(index);
        return unlink(nodeAt(index));
    }

    /**
     * Removes the element at the specified position in this list. Shifts any
     * subsequent elements to the left (subtracts one from their indices).
     * Returns the element that was removed from the list.
     *
     * @param index the index of the element to be removed
     * @return the element previously at the specified position
     * @throws IndexOutOfBoundsException if the index is out of range
     *         ({@code index < 0 || index >= size()})
     */
    public E remove(int index) {
        return removeAt(index);
    }

    /**
     * Removes the first occurrence of the specified element from this list,
     * if it is present. If this list does not contain the element, it is
     * unchanged.
     *
     * @param o element to be removed from this list, if present
     * @return {@code true} if this list contained the specified element
     */
    public boolean remove(Object o) {
        for (Node<E> x = head.next; x != tail; x = x.next) {
            if (Objects.equals(o, x.item)) {
                unlink(x);
                return true;
            }
        }
        return false;
    }

    /**
     * Removes all of the elements from this list. The list will be empty
     * after this call returns.
     */
    public void clear() {
        // Unlink all nodes to help GC
        for (Node<E> x = head.next; x != tail; ) {
            Node<E> next = x.next;
            x.item = null;
            x.prev = null;
            x.next = null;
            x = next;
        }
        head.next = tail;
        tail.prev = head;
        size = 0;
        modCount++;
    }

    // --------------- Search ---------------

    /**
     * Returns the index of the first occurrence of the specified element
     * in this list, or -1 if this list does not contain the element.
     *
     * @param o element to search for
     * @return the index of the first occurrence of the specified element in
     *         this list, or -1 if this list does not contain the element
     */
    public int indexOf(Object o) {
        int idx = 0;
        for (Node<E> x = head.next; x != tail; x = x.next) {
            if (Objects.equals(o, x.item)) return idx;
            idx++;
        }
        return -1;
    }

    /**
     * Returns the index of the last occurrence of the specified element
     * in this list, or -1 if this list does not contain the element.
     *
     * @param o element to search for
     * @return the index of the last occurrence of the specified element in
     *         this list, or -1 if this list does not contain the element
     */
    public int lastIndexOf(Object o) {
        int idx = size - 1;
        for (Node<E> x = tail.prev; x != head; x = x.prev) {
            if (Objects.equals(o, x.item)) return idx;
            idx--;
        }
        return -1;
    }

    // --------------- Iterators ---------------

    /**
     * Returns an iterator over the elements in this list in proper sequence.
     *
     * @return an iterator over the elements in this list in proper sequence
     */
    @Override
    public Iterator<E> iterator() {
        return listIterator(0);
    }

    /**
     * Returns a list iterator over the elements in this list (in proper
     * sequence), starting at the beginning of the list.
     *
     * @return a list iterator over the elements in this list (in proper
     *         sequence), starting at the beginning of the list
     */
    public ListIterator<E> listIterator() {
        return listIterator(0);
    }

    /**
     * Returns a list iterator over the elements in this list (in proper
     * sequence), starting at the specified position in the list.
     *
     * @param startIndex index of first element to be returned from the
     *        list iterator (by a call to {@code next()})
     * @return a list iterator over the elements in this list (in proper
     *         sequence), starting at the specified position in the list
     * @throws IndexOutOfBoundsException if the index is out of range
     *         ({@code index < 0 || index > size()})
     */
    public ListIterator<E> listIterator(int startIndex) {
        checkPositionIndex(startIndex);
        return new DLLListIterator(startIndex);
    }

    /**
     * List iterator implementation for DoublyLinkedList.
     * Provides bidirectional traversal and modification capabilities.
     */
    private final class DLLListIterator implements ListIterator<E> {
        private Node<E> next; // next node to return
        private Node<E> lastReturned = null; // last node returned by next()/previous()
        private int nextIndex; // index of next node
        private int expectedModCount = modCount; // fail-fast snapshot

        /**
         * Constructs a list iterator starting at the specified index.
         *
         * @param startIndex index of first element to be returned by next()
         */
        DLLListIterator(int startIndex) {
            this.next = (startIndex == size) ? tail : nodeAt(startIndex);
            this.nextIndex = startIndex;
        }

        /**
         * Checks for concurrent modification by comparing the expected
         * modification count with the current modification count.
         *
         * @throws ConcurrentModificationException if the list has been
         *         structurally modified since the iterator was created
         */
        private void checkForComodification() {
            if (expectedModCount != modCount) throw new ConcurrentModificationException();
        }

        /**
         * Returns {@code true} if this list iterator has more elements when
         * traversing the list in the forward direction.
         *
         * @return {@code true} if the list iterator has more elements
         */
        @Override public boolean hasNext() { return next != tail; }

        /**
         * Returns the next element in the list and advances the cursor position.
         *
         * @return the next element in the list
         * @throws NoSuchElementException if the iteration has no next element
         * @throws ConcurrentModificationException if the list has been modified
         *         since the iterator was created
         */
        @Override
        public E next() {
            checkForComodification();
            if (!hasNext()) throw new NoSuchElementException();
            lastReturned = next;
            next = next.next;
            nextIndex++;
            return lastReturned.item;
        }

        /**
         * Returns {@code true} if this list iterator has more elements when
         * traversing the list in the reverse direction.
         *
         * @return {@code true} if the list iterator has more elements when
         *         traversing the list in the reverse direction
         */
        @Override public boolean hasPrevious() { return (next.prev != head); }

        /**
         * Returns the previous element in the list and moves the cursor position
         * backwards.
         *
         * @return the previous element in the list
         * @throws NoSuchElementException if the iteration has no previous element
         * @throws ConcurrentModificationException if the list has been modified
         *         since the iterator was created
         */
        @Override
        public E previous() {
            checkForComodification();
            Node<E> prev = next.prev;
            if (prev == head) throw new NoSuchElementException();
            next = prev;
            lastReturned = next;
            nextIndex--;
            return lastReturned.item;
        }

        /**
         * Returns the index of the element that would be returned by a subsequent
         * call to {@code next()}.
         *
         * @return the index of the element that would be returned by a subsequent
         *         call to {@code next()}, or {@code size()} if the list iterator
         *         is at the end of the list
         */
        @Override public int nextIndex() { return nextIndex; }

        /**
         * Returns the index of the element that would be returned by a subsequent
         * call to {@code previous()}.
         *
         * @return the index of the element that would be returned by a subsequent
         *         call to {@code previous()}, or -1 if the list iterator is at the
         *         beginning of the list
         */
        @Override public int previousIndex() { return nextIndex - 1; }

        /**
         * Removes from the list the last element that was returned by
         * {@code next()} or {@code previous()}.
         *
         * @throws IllegalStateException if neither {@code next()} nor
         *         {@code previous()} have been called, or {@code remove()} or
         *         {@code add()} have been called after the last call to
         *         {@code next()} or {@code previous()}
         * @throws ConcurrentModificationException if the list has been modified
         *         since the iterator was created
         */
        @Override
        public void remove() {
            checkForComodification();
            if (lastReturned == null) throw new IllegalStateException();
            Node<E> toRemove = lastReturned;
            // Adjust iterator position if removing the node before 'next'
            if (toRemove == next) {
                next = next.next;
            } else {
                nextIndex--;
            }
            unlink(toRemove);
            lastReturned = null;
            expectedModCount = modCount;
        }

        /**
         * Replaces the last element returned by {@code next()} or {@code previous()}
         * with the specified element.
         *
         * @param e the element with which to replace the last element returned
         * @throws IllegalStateException if neither {@code next()} nor
         *         {@code previous()} have been called, or {@code remove()} or
         *         {@code add()} have been called after the last call to
         *         {@code next()} or {@code previous()}
         * @throws ConcurrentModificationException if the list has been modified
         *         since the iterator was created
         */
        @Override
        public void set(E e) {
            checkForComodification();
            if (lastReturned == null) throw new IllegalStateException();
            lastReturned.item = e;
            // Non-structural: no modCount change
        }

        /**
         * Inserts the specified element into the list. The element is inserted
         * immediately before the element that would be returned by {@code next()},
         * if any, and after the element that would be returned by {@code previous()},
         * if any.
         *
         * @param e the element to insert
         * @throws ConcurrentModificationException if the list has been modified
         *         since the iterator was created
         */
        @Override
        public void add(E e) {
            checkForComodification();
            linkBetween(e, next.prev, next);
            nextIndex++;
            lastReturned = null;
            expectedModCount = modCount;
        }
    }

    // --------------- Helpers ---------------

    /**
     * Links a new node containing the specified element between the given
     * previous and next nodes. Updates the size and modification count.
     *
     * @param e the element to insert
     * @param prev the node that will precede the new node
     * @param next the node that will follow the new node
     */
    private void linkBetween(E e, Node<E> prev, Node<E> next) {
        Node<E> n = new Node<>(e, prev, next);
        prev.next = n;
        next.prev = n;
        size++;
        modCount++;
    }

    /**
     * Unlinks the specified node from the list. Updates the size and modification
     * count, and helps garbage collection by nulling out references.
     *
     * @param n the node to unlink
     * @return the element that was stored in the unlinked node
     */
    private E unlink(Node<E> n) {
        Node<E> prev = n.prev;
        Node<E> next = n.next;
        prev.next = next;
        next.prev = prev;
        E item = n.item;
        // Help GC
        n.item = null;
        n.prev = null;
        n.next = null;
        size--;
        modCount++;
        return item;
    }

    /**
     * Returns the node at the specified index. Optimizes traversal by starting
     * from the nearest end (head or tail) based on the index position.
     *
     * @param index the index of the node to return (must be valid)
     * @return the node at the specified index
     */
    private Node<E> nodeAt(int index) {
        // index is assumed valid
        if (index < (size >> 1)) {
            Node<E> x = head.next;
            for (int i = 0; i < index; i++) x = x.next;
            return x;
        } else {
            Node<E> x = tail.prev;
            for (int i = size - 1; i > index; i--) x = x.prev;
            return x;
        }
    }

    /**
     * Checks if the specified index is a valid element index (for get/set/remove
     * operations). An element index is valid if it is between 0 (inclusive) and
     * size (exclusive).
     *
     * @param index the index to check
     * @throws IndexOutOfBoundsException if the index is out of range
     */
    private void checkElementIndex(int index) {
        if (index < 0 || index >= size)
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
    }

    /**
     * Checks if the specified index is a valid position index (for add operations).
     * A position index is valid if it is between 0 (inclusive) and size (inclusive).
     *
     * @param index the index to check
     * @throws IndexOutOfBoundsException if the index is out of range
     */
    private void checkPositionIndex(int index) {
        if (index < 0 || index > size)
            throw new IndexOutOfBoundsException("Index: " + index + ", Size: " + size);
    }

    // --------------- Array conversion ---------------

    /**
     * Returns an array containing all of the elements in this list in proper
     * sequence (from first to last element).
     *
     * @return an array containing all of the elements in this list in proper
     *         sequence
     */
    public Object[] toArray() {
        Object[] array = new Object[size];
        int i = 0;
        for (E e : this) {
            array[i++] = e;
        }
        return array;
    }

    /**
     * Returns an array containing all of the elements in this list in proper
     * sequence (from first to last element); the runtime type of the returned
     * array is that of the specified array. If the list fits in the specified
     * array, it is returned therein. Otherwise, a new array is allocated with
     * the runtime type of the specified array and the size of this list.
     *
     * @param <T> the runtime type of the array to contain the collection
     * @param a the array into which the elements of this list are to be stored,
     *          if it is big enough; otherwise, a new array of the same runtime
     *          type is allocated for this purpose
     * @return an array containing the elements of this list
     * @throws ArrayStoreException if the runtime type of the specified array
     *         is not a supertype of the runtime type of every element in this list
     * @throws NullPointerException if the specified array is null
     */
    @SuppressWarnings("unchecked")
    // Suppression is safe: we create an array of the exact component type requested
    // (via Array.newInstance), and the cast from E to T is validated at runtime
    // by the ArrayStoreException contract. The generic type system cannot verify
    // this at compile time, hence the unchecked cast warnings is forcefully suppressed.
    public <T> T[] toArray(T[] a) {
        if (a == null) throw new NullPointerException("Array cannot be null");
        if (a.length < size) {
            a = (T[]) java.lang.reflect.Array.newInstance(
                    a.getClass().getComponentType(), size);
        }
        int i = 0;
        for (E e : this) {
            a[i++] = (T) e;
        }
        if (a.length > size) {
            a[size] = null;
        }
        return a;
    }

    /**
     * Compares the specified object with this list for equality. Returns
     * {@code true} if and only if the specified object is also a
     * {@code DoublyLinkedList}, both lists have the same size, and all
     * corresponding pairs of elements in the two lists are equal.
     *
     * @param obj the object to be compared for equality with this list
     * @return {@code true} if the specified object is equal to this list
     */
    @Override
    public boolean equals(Object obj) {
        if (this == obj) return true;
        if (obj == null || getClass() != obj.getClass()) return false;
        DoublyLinkedList<?> other = (DoublyLinkedList<?>) obj;
        if (size != other.size) return false;
        Iterator<E> it1 = iterator();
        Iterator<?> it2 = other.iterator();
        while (it1.hasNext()) {
            if (!it2.hasNext()) return false;
            E e1 = it1.next();
            Object e2 = it2.next();
            if (!Objects.equals(e1, e2)) return false;
        }
        return !it2.hasNext();
    }

    /**
     * Returns the hash code value for this list. The hash code of a list is
     * defined to be the result of the following calculation:
     * <pre>{@code
     *     int hashCode = 1;
     *     for (E e : list)
     *         hashCode = 31 * hashCode + (e == null ? 0 : e.hashCode());
     * }</pre>
     *
     * @return the hash code value for this list
     */
    @Override
    public int hashCode() {
        int hash = 1;
        for (E e : this) {
            hash = 31 * hash + (e == null ? 0 : e.hashCode());
        }
        return hash;
    }

    /**
     * Returns a shallow copy of this {@code DoublyLinkedList}. (The elements
     * themselves are not cloned.)
     *
     * @return a shallow copy of this {@code DoublyLinkedList} instance
     */
    @Override
    public DoublyLinkedList<E> clone() {
        DoublyLinkedList<E> copy = new DoublyLinkedList<>();
        for (E e : this) copy.addLast(e);
        return copy;
    }

    /**
     * Returns a string representation of this list. The string representation
     * consists of a list of the list's elements in the order they are returned
     * by its iterator, enclosed in square brackets ({@code "[]"}). Adjacent
     * elements are separated by the characters {@code ", "} (comma and space).
     *
     * @return a string representation of this list
     */
    @Override
    public String toString() {
        StringBuilder sb = new StringBuilder();
        sb.append("[");
        Node<E> x = head.next;
        while (x != tail) {
            sb.append(x.item);
            x = x.next;
            if (x != tail) sb.append(", ");
        }
        sb.append("]");
        return sb.toString();
    }
}

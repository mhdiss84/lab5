package com.example.dlist;

import java.util.NoSuchElementException;
import java.util.Objects;

/**
 * A queue (FIFO - First In, First Out) implementation backed by {@link DoublyLinkedList}.
 *
 * <p>This implementation provides constant-time operations for the basic queue
 * operations. Elements are added at the tail (rear) and removed from the head
 * (front) of the underlying doubly linked list.</p>
 *
 * <p>Performance characteristics:</p>
 * <ul>
 *   <li>offer/poll/peek: O(1) time complexity</li>
 *   <li>size/isEmpty: O(1) time complexity</li>
 *   <li>clear: O(n) time complexity</li>
 * </ul>
 *
 * <p>Null values are not permitted to keep {@code peek}/{@code poll} semantics
 * unambiguous. This allows {@code poll()} and {@code peek()} to return {@code null}
 * to indicate an empty queue without ambiguity.</p>
 *
 * @param <E> the type of elements held in this queue
 * @see DoublyLinkedList
 */
public final class LinkedQueue<E> {
    /** The underlying doubly linked list backing this queue. */
    private final DoublyLinkedList<E> list = new DoublyLinkedList<>();

    /**
     * Constructs an empty queue.
     */
    public LinkedQueue() {
    }

    /**
     * Inserts the specified element into this queue. This method always returns
     * {@code true} as the queue has no capacity restrictions.
     *
     * @param e the element to add
     * @return {@code true} (as specified by the queue contract)
     * @throws NullPointerException if the specified element is null
     */
    public boolean offer(E e) {
        Objects.requireNonNull(e, "Queue does not permit null elements");
        list.addLast(e);
        return true;
    }

    /**
     * Convenience alias for {@link #offer(Object)}. Inserts the specified element
     * into this queue.
     *
     * @param e the element to add
     * @throws NullPointerException if the specified element is null
     */
    public void enqueue(E e) {
        offer(e);
    }

    /**
     * Retrieves and removes the head of this queue, or returns {@code null}
     * if this queue is empty.
     *
     * @return the head of this queue, or {@code null} if this queue is empty
     */
    public E poll() {
        return list.isEmpty() ? null : list.removeFirst();
    }

    /**
     * Convenience alias for a strict remove operation. Retrieves and removes
     * the head of this queue.
     *
     * @return the head of this queue
     * @throws NoSuchElementException if this queue is empty
     */
    public E dequeue() {
        if (list.isEmpty()) throw new NoSuchElementException("Queue is empty");
        return list.removeFirst();
    }

    /**
     * Retrieves, but does not remove, the head of this queue, or returns
     * {@code null} if this queue is empty.
     *
     * @return the head of this queue, or {@code null} if this queue is empty
     */
    public E peek() {
        return list.isEmpty() ? null : list.getFirst();
    }

    /**
     * Returns the number of elements in this queue.
     *
     * @return the number of elements in this queue
     */
    public int size() {
        return list.size();
    }

    /**
     * Returns {@code true} if this queue contains no elements.
     *
     * @return {@code true} if this queue contains no elements
     */
    public boolean isEmpty() {
        return list.isEmpty();
    }

    /**
     * Removes all of the elements from this queue. The queue will be empty
     * after this call returns.
     */
    public void clear() {
        list.clear();
    }

    /**
     * Returns a string representation of this queue. The string representation
     * consists of a list of the queue's elements in the order they would be
     * dequeued (from head to tail), enclosed in square brackets ({@code "[]"}).
     * Adjacent elements are separated by the characters {@code ", "} (comma and space).
     *
     * @return a string representation of this queue
     */
    @Override
    public String toString() {
        return list.toString();
    }
}

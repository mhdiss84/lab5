# Java Collections: Doubly Linked List, Stack, Queue, and BST

Generic, production-quality data structures with clean OOP design, thorough tests, and Javadoc.

## Table of Contents
- Overview
- Requirements
- Build & Test
- Project Layout
- DoublyLinkedList (sentinel-based)
- LinkedStack (LIFO)
- LinkedQueue (FIFO)
- BinarySearchTree (BST)
- Complexity Cheatsheet
- Design Decisions
- Nulls & Exceptions
- Thread Safety
- Examples
- Traversal Details
- Javadoc

## Overview
- Sentinel-based, generic `DoublyLinkedList<E>` with fail‑fast iterators and optimized index access
- `LinkedStack<E>` and `LinkedQueue<E>` implemented on top of the list
- `BinarySearchTree<E>` with comparator support, DFS (in/pre/post) and BFS traversals, remove/min/max/height
- Comprehensive JUnit tests and generated Javadoc

## Requirements
- Java 17+
- Maven 3.8+

## Build & Test
- Compile: `mvn -q compile`
- Test: `mvn -q test`
- Package: `mvn -q package`
- Javadoc: `mvn -q javadoc:javadoc` → `target/site/apidocs/index.html`

## Project Layout
- Sources
  - `src/main/java/com/example/dlist/DoublyLinkedList.java`
  - `src/main/java/com/example/dlist/LinkedStack.java`
  - `src/main/java/com/example/dlist/LinkedQueue.java`
  - `src/main/java/com/example/tree/BinarySearchTree.java`
- Tests
  - `src/test/java/com/example/dlist/*.java`
  - `src/test/java/com/example/tree/BinarySearchTreeTest.java`
- Build file: `pom.xml`

## DoublyLinkedList
Key features
- Head/tail sentinels remove edge cases for first/last operations
- Encapsulated `linkBetween`/`unlink` preserve invariants in O(1)
- Fail‑fast `Iterator`/`ListIterator` (structural changes only)
- `equals`/`hashCode` consistent with element order and contents
- `toArray()` and `toArray(T[] a)` convenience

API highlights
- Access: `getFirst()`, `getLast()`, `get(int)`, `set(int, E)`
- Add: `addFirst(E)`, `addLast(E)`, `add(int, E)`, `add(E)`
- Remove: `removeFirst()`, `removeLast()`, `removeAt(int)`, `remove(int)`, `remove(Object)`
- Search: `indexOf(Object)`, `lastIndexOf(Object)`, `contains(Object)`
- Iteration: `iterator()`, `listIterator([int start])`
- Misc: `size()`, `isEmpty()`, `clear()`, `clone()`, `toString()`

Iteration semantics
- Fail‑fast on structural modifications after iterator creation
- `ListIterator` supports `add`, `remove`, and non‑structural `set`

## LinkedStack
LIFO stack using the list. Nulls not allowed.
- `push(E)`: O(1)
- `pop()`: O(1), throws `EmptyStackException` if empty
- `peek()`: O(1), throws `EmptyStackException` if empty
- `size()`, `isEmpty()`, `clear()`, `toString()`

## LinkedQueue
FIFO queue using the list. Nulls not allowed.
- `offer(E)` / `enqueue(E)`: O(1)
- `poll()`: O(1), returns null if empty
- `dequeue()`: O(1), throws `NoSuchElementException` if empty
- `peek()`, `size()`, `isEmpty()`, `clear()`, `toString()`

## BinarySearchTree (BST)
Generic BST with optional comparator (natural ordering if none).
- Core: `add(E)`, `contains(E)`, `remove(E)`, `size()`, `isEmpty()`, `clear()`
- Traversals: `inorder()`, `preorder()`, `postorder()`, `levelOrder()`
- Utilities: `min()`, `max()`, `height()`
- Iterator: lazy in‑order (O(h) memory), no fail‑fast

Remove semantics
- 0 children: remove node
- 1 child: splice child up
- 2 children: replace with in‑order successor (min of right subtree)

## Complexity Cheatsheet
- DoublyLinkedList
  - `addFirst/addLast/removeFirst/removeLast`: O(1)
  - `get/set/removeAt/add(index)`: O(min(index, n-index))
  - `contains/indexOf/lastIndexOf`: O(n)
- LinkedStack/LinkedQueue: O(1) per primary op
- BST (average): `add/contains/remove`: O(log n); worst‑case O(n)
- Traversals: O(n)

## Design Decisions
- Sentinel nodes (list): unify boundaries; fewer branches; simpler invariants
- Structural vs non‑structural changes: only structural increments `modCount`
- Fail‑fast list iterators vs non‑fail‑fast BST iterator (simplicity, low allocation)
- `clone()` on list is shallow; elements are not cloned
- `equals` on list compares element‑wise with same concrete type for symmetry

## Nulls & Exceptions
- DoublyLinkedList: allows null elements; search uses `Objects.equals`
- LinkedStack/LinkedQueue: reject nulls for unambiguous semantics
- BST: rejects nulls (ordering undefined); `min/max` throw `NoSuchElementException` when empty

## Thread Safety
- All structures are not thread‑safe. Synchronize externally if used concurrently.
- Iterators are not safe for concurrent structural modifications. List iterators fail‑fast; BST iterator does not.

## Examples

### DoublyLinkedList quick start
```java
var list = new com.example.dlist.DoublyLinkedList<String>();
list.addFirst("b");
list.addFirst("a");
list.addLast("c"); // [a, b, c]
for (String s : list) { /* ... */ }
```

### Stack
```java
var stack = new com.example.dlist.LinkedStack<Integer>();
stack.push(1); stack.push(2); stack.push(3);
stack.pop(); // 3
```

### Queue
```java
var q = new com.example.dlist.LinkedQueue<String>();
q.offer("a"); q.enqueue("b"); q.offer("c");
q.poll(); // "a"
```

### BST
```java
var bst = new com.example.tree.BinarySearchTree<Integer>();
for (int v : new int[]{8,3,10,1,6,14,4,7,13}) bst.add(v);
bst.inorder();   // sorted
bst.levelOrder(); // BFS
bst.remove(3);
```

## Traversal Details

Binary tree traversal strategies determine the order nodes are visited:

- DFS (Depth‑First Search)
  - Pre‑order (Node, Left, Right) — visit node before its children
  - In‑order (Left, Node, Right) — for BSTs, yields sorted order
  - Post‑order (Left, Right, Node) — visit node after its children
- BFS (Breadth‑First Search) / Level‑order — visit nodes level by level from the root.
  - **Implementation using a queue**: The algorithm uses a queue to maintain the order of nodes to visit.
    - **Initialization**: Start by enqueueing the root node.
    - **Process loop**: While the queue is not empty:
      1. **Dequeue** the front node (this is the current node to visit)
      2. **Process** the current node (add its value to the result)
      3. **Enqueue** the left child (if it exists)
      4. **Enqueue** the right child (if it exists)
    - This ensures nodes are visited level by level, left to right within each level.
    - The queue naturally maintains the correct order: nodes at level N are processed before nodes at level N+1.
  
  **Step-by-step example** (using the tree below):
  ```
  Queue: [8]                    → Dequeue 8, process it, enqueue 3 and 10
  Queue: [3, 10]               → Dequeue 3, process it, enqueue 1 and 6
  Queue: [10, 1, 6]            → Dequeue 10, process it, enqueue 14
  Queue: [1, 6, 14]            → Dequeue 1, process it (no children)
  Queue: [6, 14]               → Dequeue 6, process it, enqueue 4 and 7
  Queue: [14, 4, 7]            → Dequeue 14, process it, enqueue 13
  Queue: [4, 7, 13]            → Dequeue 4, process it (no children)
  Queue: [7, 13]               → Dequeue 7, process it (no children)
  Queue: [13]                  → Dequeue 13, process it (no children)
  Queue: []                    → Empty, traversal complete
  
  Result: [8, 3, 10, 1, 6, 14, 4, 7, 13]
  ```
  
  **Why a queue works**: The FIFO (First In, First Out) property ensures that:
  - Nodes at the same level are processed in left-to-right order
  - All nodes at level N are processed before any node at level N+1
  - Children are added to the back of the queue, preserving the level-by-level order

Using the example BST built by inserting `[8, 3, 10, 1, 6, 14, 4, 7, 13]`:

```
        8
      /   \
     3     10
    / \      \
   1   6      14
      / \     /
     4   7   13
```

- Pre‑order (NLR): `[8, 3, 1, 6, 4, 7, 10, 14, 13]`
- In‑order (LNR): `[1, 3, 4, 6, 7, 8, 10, 13, 14]` (sorted for BST)
- Post‑order (LRN): `[1, 4, 7, 6, 3, 13, 14, 10, 8]`
- Level‑order (BFS): `[8, 3, 10, 1, 6, 14, 4, 7, 13]`

Complexity
- Time: all traversals run in O(n)
- Space: DFS uses O(h) auxiliary space (h = height). BFS uses O(w) (w = max width).

Typical uses
- Pre‑order: copy/serialize tree, prefix expression evaluation
- In‑order: sorted enumeration for BSTs, range queries
- Post‑order: safe deletion/freeing resources, postfix evaluation
- Level‑order (BFS): shortest path in unweighted trees, level grouping, serialization

How we implements them:
- `BinarySearchTree.inorder()/preorder()/postorder()` are recursive helpers that collect into a list
- `BinarySearchTree.levelOrder()` uses our `LinkedQueue` to scan level by level
- `BinarySearchTree.iterator()` is a lazy in‑order traversal using an explicit stack (`ArrayDeque`), O(h) memory and no intermediate list

## Javadoc
- Generate: `mvn -q javadoc:javadoc`
- Open: `target/site/apidocs/index.html`
